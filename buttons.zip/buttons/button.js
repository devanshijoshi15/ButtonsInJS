//quest1
let newBtn = document.createElement("button");
newBtn.innerText = "click me!";
newBtn.style.color = "white";
newBtn.style.backgroundColor = "yellow";

document.querySelector("body").prepend(newBtn);

//quest2
let para = document.querySelector("p");
para.getAttribute("class") //content
para.setAttribute("class")

